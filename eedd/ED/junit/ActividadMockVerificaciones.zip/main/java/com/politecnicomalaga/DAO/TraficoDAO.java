package com.politecnicomalaga.DAO;

import com.politecnicomalaga.modelo.Persona;
import com.politecnicomalaga.modelo.Vehiculo;

public class TraficoDAO {
    public Vehiculo getVehiculoByMatricula(String matricula){
        return null;
    }

    public Persona getPropietarioByDNI(String DNI){
        return null;
    }
}
